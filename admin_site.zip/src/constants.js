// var mainurl = "http://98.130.15.185:8000";
// var mainurl = "http://127.0.0.1:8000";
var mainurl = "https://navconnect.onrender.com";

export default mainurl;
